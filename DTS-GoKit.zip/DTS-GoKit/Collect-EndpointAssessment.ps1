<#
.SYNOPSIS
    Read-only hardware and health assessment of one Windows machine: one folder of CSVs, a one-page summary
    with flagged findings, and a zip. Changes nothing on the machine.

.DESCRIPTION
    WINDOWS POWERSHELL 5.1 COMPATIBLE (customer machines). Run elevated for the full picture (TPM, BitLocker,
    disk health and Defender need admin); without admin those sections say "needs admin" instead of failing.
    Each section has its own try/catch - one failure never stops the run. Sections:
      System (make, model, serial, BIOS, age), OS (edition, build, install date, last boot, last patch),
      CPU, Memory, Disks (health, wear, temperature where reported), Volumes (free space, BitLocker),
      Security (TPM, Secure Boot, Defender, other antivirus, firewall), Windows 11 readiness (TPM 2.0,
      Secure Boot, RAM, disk, CPU listed for review), Battery (design vs full-charge capacity), LocalAdmins,
      Profiles, Software, Startup, Services (automatic but stopped), Events (errors in the last 7 days),
      Crashes (application failures in the last 30 days), Network (adapters, IP, DNS), Updates (hotfixes,
      pending reboot), Printers, Shares.
    Output: <OutputRoot>\<COMPUTER>-endpoint-<yyyyMMdd-HHmmss>\ with one CSV per section, Summary.txt,
    Findings.csv, Results.csv (section status), Log.csv - and the same folder as a .zip next to it.

.PARAMETER OutputRoot
    Where the run folder goes. Default: an 'Output' folder next to this script (on the USB stick when run
    from it; under C:\ProgramData\DTS\Assessment when the script folder is not writable).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Collect-EndpointAssessment.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Collect-EndpointAssessment.ps1 -OutputRoot D:\Scans

.NOTES
    DTS Go kit (Projects\GoStick\README.md). Written 2026-11-16 (Bench). Read-only: no setting, file or service
    on the machine is changed (powercfg writes its battery report into the run folder only). Collects names of
    local accounts, installed software and network settings - no documents, mail, browser data or passwords.
    Customer data: the zip goes to the customer's folder (Customers\<Customer>\Input), never into git.
    Not yet in the assessment kit checklist (PM\AssessmentKit) - planned.
#>
[CmdletBinding()]
param(
    [string] $OutputRoot,
    [int]    $EventDays = 7,
    [int]    $CrashDays = 30
)
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $OutputRoot) { $OutputRoot = Join-Path $scriptDir 'Output' }
try { if (-not (Test-Path $OutputRoot)) { New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null }; $probe = Join-Path $OutputRoot ".w$stamp"; Set-Content $probe 'x'; Remove-Item $probe }
catch { $OutputRoot = 'C:\ProgramData\DTS\Assessment'; New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null }
$run = Join-Path $OutputRoot ("{0}-endpoint-{1}" -f $env:COMPUTERNAME, $stamp)
New-Item -ItemType Directory -Path $run -Force | Out-Null

$isAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$results = New-Object System.Collections.Generic.List[object]
$log = New-Object System.Collections.Generic.List[object]
$findings = New-Object System.Collections.Generic.List[object]
$facts = [ordered]@{}

function Write-Step([string]$Step, [string]$Level, [string]$Message) {
    $log.Add([pscustomobject]@{ Time = (Get-Date -Format 's'); Step = $Step; Level = $Level; Message = $Message })
    Write-Host ('  {0,-14} {1,-9} {2}' -f $Step, $Level, $Message)
}
function Add-Finding([string]$Severity, [string]$Area, [string]$Text) { $findings.Add([pscustomobject]@{ Severity = $Severity; Area = $Area; Finding = $Text }) }
function Invoke-Section([string]$Name, [scriptblock]$Body, [switch]$NeedsAdmin) {
    if ($NeedsAdmin -and -not $isAdmin) { Write-Step $Name 'Skipped' 'needs admin'; $results.Add([pscustomobject]@{ Section = $Name; Status = 'NeedsAdmin'; Rows = 0; Detail = 'run elevated' }); return }
    try {
        $rows = @(& $Body | Where-Object { $_ })
        if ($rows.Count) { $rows | Export-Csv (Join-Path $run "$Name.csv") -NoTypeInformation }
        Write-Step $Name 'Collected' ("{0} row(s)" -f $rows.Count)
        $results.Add([pscustomobject]@{ Section = $Name; Status = 'Collected'; Rows = $rows.Count; Detail = '' })
    } catch {
        Write-Step $Name 'Error' $_.Exception.Message
        $results.Add([pscustomobject]@{ Section = $Name; Status = 'Error'; Rows = 0; Detail = $_.Exception.Message })
    }
}
function Get-GB($b) { if ($b) { [math]::Round([double]$b / 1GB, 1) } else { $null } }

Write-Host ''
Write-Host "DTS endpoint assessment - read-only - $env:COMPUTERNAME$(if (-not $isAdmin) { ' (NOT elevated: some sections skipped)' })" -ForegroundColor Cyan

Invoke-Section 'System' {
    $cs = Get-CimInstance Win32_ComputerSystem; $bios = Get-CimInstance Win32_BIOS; $enc = @(Get-CimInstance Win32_SystemEnclosure)[0]
    $prod = Get-CimInstance Win32_ComputerSystemProduct
    $biosDate = $bios.ReleaseDate
    $age = if ($biosDate) { [math]::Round(((Get-Date) - $biosDate).TotalDays / 365.25, 1) } else { $null }
    $chassis = switch (@($enc.ChassisTypes)[0]) { { $_ -in 8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32 } { 'Laptop' } { $_ -in 3, 4, 5, 6, 7, 15, 16, 35, 36 } { 'Desktop' } 13 { 'All-in-one' } default { "Type $_" } }
    $facts.Make = $cs.Manufacturer; $facts.Model = $cs.Model; $facts.Serial = $bios.SerialNumber; $facts.Chassis = $chassis; $facts.BiosDate = $biosDate; $facts.ApproxAgeYears = $age
    $facts.Domain = $(if ($cs.PartOfDomain) { $cs.Domain } else { "Workgroup $($cs.Workgroup)" })
    if ($age -ge 6) { Add-Finding 'Medium' 'Hardware' "Firmware dated $($biosDate.ToString('yyyy-MM-dd')) - machine is roughly $age years old." }
    [pscustomobject]@{ Computer = $env:COMPUTERNAME; Manufacturer = $cs.Manufacturer; Model = $cs.Model; SystemSku = $cs.SystemSKUNumber; Serial = $bios.SerialNumber
        Uuid = $prod.UUID; Chassis = $chassis; BiosVersion = $bios.SMBIOSBIOSVersion; BiosDate = $biosDate; ApproxAgeYears = $age; Domain = $facts.Domain
        LoggedOnUser = $cs.UserName; RamGB = Get-GB $cs.TotalPhysicalMemory
        WarrantyLookup = $(if ($cs.Manufacturer -match 'Dell') { "https://www.dell.com/support/home/en-us/product-support/servicetag/$($bios.SerialNumber)" } elseif ($cs.Manufacturer -match 'HP|Hewlett') { 'https://support.hp.com/us-en/check-warranty' } elseif ($cs.Manufacturer -match 'Lenovo') { 'https://pcsupport.lenovo.com/us/en/warrantylookup' } else { '' }) }
}
Invoke-Section 'OS' {
    $os = Get-CimInstance Win32_OperatingSystem
    $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $up = (Get-Date) - $os.LastBootUpTime
    $facts.OS = "$($os.Caption) $($cv.DisplayVersion) (build $($os.BuildNumber).$($cv.UBR))"; $facts.LastBoot = $os.LastBootUpTime
    if ($up.TotalDays -gt 30) { Add-Finding 'Medium' 'Updates' ("Not restarted in {0:N0} days (last boot {1:yyyy-MM-dd}) - updates may be waiting on a restart." -f $up.TotalDays, $os.LastBootUpTime) }
    if ($os.Caption -match 'Windows 10') { Add-Finding 'High' 'OS' 'Windows 10 - out of mainstream support since 2025-10-14 (ESU only). Plan the Windows 11 move or replacement.' }
    [pscustomobject]@{ Caption = $os.Caption; DisplayVersion = $cv.DisplayVersion; Build = "$($os.BuildNumber).$($cv.UBR)"; Architecture = $os.OSArchitecture
        InstallDate = $os.InstallDate; LastBoot = $os.LastBootUpTime; UptimeDays = [math]::Round($up.TotalDays, 1); RegisteredOwner = $cv.RegisteredOwner; Locale = $os.Locale }
}
Invoke-Section 'CPU' {
    $c = @(Get-CimInstance Win32_Processor)
    $facts.CPU = $c[0].Name.Trim()
    $c | ForEach-Object { [pscustomobject]@{ Name = $_.Name.Trim(); Cores = $_.NumberOfCores; Threads = $_.NumberOfLogicalProcessors; MaxMHz = $_.MaxClockSpeed; LoadPct = $_.LoadPercentage } }
}
Invoke-Section 'Memory' {
    $m = @(Get-CimInstance Win32_PhysicalMemory)
    $tot = Get-GB (($m | Measure-Object Capacity -Sum).Sum); $facts.RamGB = $tot
    if ($tot -lt 8) { Add-Finding 'High' 'Hardware' "$tot GB RAM - below 8 GB is slow for current Windows and Office." } elseif ($tot -lt 16) { Add-Finding 'Low' 'Hardware' "$tot GB RAM - fine for basic use; 16 GB recommended for heavier work." }
    $m | ForEach-Object { [pscustomobject]@{ Slot = $_.DeviceLocator; SizeGB = Get-GB $_.Capacity; SpeedMHz = $_.Speed; Manufacturer = $_.Manufacturer; PartNumber = "$($_.PartNumber)".Trim() } }
}
Invoke-Section 'Disks' {
    foreach ($d in @(Get-PhysicalDisk)) {
        $rc = $null; try { $rc = $d | Get-StorageReliabilityCounter -ErrorAction Stop } catch { }
        if ($d.HealthStatus -ne 'Healthy') { Add-Finding 'High' 'Disk' "Disk '$($d.FriendlyName)' reports health $($d.HealthStatus) - back up and replace." }
        if ($rc -and $rc.Wear -ge 80) { Add-Finding 'High' 'Disk' "SSD '$($d.FriendlyName)' wear $($rc.Wear)% - near end of life." }
        if ($d.MediaType -eq 'HDD' -and -not $facts.HddFlagged) { $facts.HddFlagged = $true; Add-Finding 'Medium' 'Disk' "Spinning hard disk '$($d.FriendlyName)' - an SSD would make this machine much faster." }
        [pscustomobject]@{ Name = $d.FriendlyName; Media = $d.MediaType; Bus = $d.BusType; SizeGB = Get-GB $d.Size; Health = $d.HealthStatus; Operational = ($d.OperationalStatus -join ',')
            WearPct = $(if ($rc) { $rc.Wear }); TempC = $(if ($rc) { $rc.Temperature }); PowerOnHours = $(if ($rc) { $rc.PowerOnHours }); ReadErrors = $(if ($rc) { $rc.ReadErrorsUncorrected }); Serial = "$($d.SerialNumber)".Trim() }
    }
} -NeedsAdmin
Invoke-Section 'Volumes' {
    $bl = @{}; if ($isAdmin) { try { foreach ($b in @(Get-BitLockerVolume -ErrorAction Stop)) { $bl[$b.MountPoint] = $b } } catch { } }
    foreach ($v in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        $pct = if ($v.Size) { [math]::Round(100 * $v.FreeSpace / $v.Size, 0) } else { $null }
        if ($pct -ne $null -and $pct -lt 10) { Add-Finding 'High' 'Disk' "Drive $($v.DeviceID) only $pct% free ($(Get-GB $v.FreeSpace) GB)." } elseif ($pct -ne $null -and $pct -lt 20) { Add-Finding 'Low' 'Disk' "Drive $($v.DeviceID) $pct% free." }
        $b = $bl[$v.DeviceID]
        if ($v.DeviceID -eq $env:SystemDrive) {
            $facts.SystemDriveFreePct = $pct
            if ($isAdmin -and (-not $b -or $b.ProtectionStatus -ne 'On')) { Add-Finding 'High' 'Security' "BitLocker is not protecting the system drive $($v.DeviceID) - a lost or stolen machine exposes its data." }
            $facts.BitLocker = $(if ($b) { "$($b.ProtectionStatus) ($($b.VolumeStatus))" } elseif ($isAdmin) { 'Off' } else { 'unknown (needs admin)' })
        }
        [pscustomobject]@{ Drive = $v.DeviceID; Label = $v.VolumeName; FileSystem = $v.FileSystem; SizeGB = Get-GB $v.Size; FreeGB = Get-GB $v.FreeSpace; FreePct = $pct
            BitLocker = $(if ($b) { "$($b.ProtectionStatus)" } elseif ($isAdmin) { 'Off' } else { 'needs admin' }); Encryption = $(if ($b) { "$($b.EncryptionMethod) $($b.EncryptionPercentage)%" }) }
    }
}
Invoke-Section 'Security' {
    $rows = @()
    $tpm = $null; if ($isAdmin) { try { $tpm = Get-Tpm -ErrorAction Stop } catch { } }
    $tpmVer = $null; try { $tw = Get-CimInstance -Namespace 'root\cimv2\Security\MicrosoftTpm' -ClassName Win32_Tpm -ErrorAction Stop; $tpmVer = ("$($tw.SpecVersion)" -split ',')[0].Trim() } catch { }
    $facts.TPM = $(if ($tpm) { "present $($tpm.TpmPresent), ready $($tpm.TpmReady), version $tpmVer" } elseif ($tpmVer) { "version $tpmVer" } elseif ($isAdmin) { 'not found' } else { 'unknown (needs admin)' })
    if ($isAdmin -and -not ($tpm -and $tpm.TpmPresent)) { Add-Finding 'High' 'Security' 'No TPM found (or disabled in firmware) - needed for Windows 11 and BitLocker.' }
    $sb = $null; try { $sb = Confirm-SecureBootUEFI -ErrorAction Stop } catch { $sb = $null }
    $facts.SecureBoot = $(if ($sb -eq $true) { 'On' } elseif ($sb -eq $false) { 'Off' } else { 'Not supported / legacy BIOS / needs admin' })
    if ($sb -eq $false) { Add-Finding 'Medium' 'Security' 'Secure Boot is off.' }
    $rows += [pscustomobject]@{ Item = 'TPM'; Value = $facts.TPM }
    $rows += [pscustomobject]@{ Item = 'SecureBoot'; Value = $facts.SecureBoot }
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $sigAge = $mp.AntivirusSignatureAge
        $facts.Defender = "real-time $($mp.RealTimeProtectionEnabled), signatures $sigAge day(s) old, mode $($mp.AMRunningMode)"
        if ($mp.AMRunningMode -eq 'Normal' -and -not $mp.RealTimeProtectionEnabled) { Add-Finding 'High' 'Security' 'Microsoft Defender real-time protection is OFF.' }
        if ($mp.AMRunningMode -eq 'Normal' -and $sigAge -gt 3) { Add-Finding 'Medium' 'Security' "Defender signatures are $sigAge days old." }
        $rows += [pscustomobject]@{ Item = 'Defender'; Value = $facts.Defender }
    } catch { $rows += [pscustomobject]@{ Item = 'Defender'; Value = "not readable: $($_.Exception.Message)" } }
    try {
        $av = @(Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction Stop)
        foreach ($a in $av) { $hex = '{0:X6}' -f [int]$a.productState; $on = $hex.Substring(2, 2) -in '10', '11'; $rows += [pscustomobject]@{ Item = 'Antivirus'; Value = "$($a.displayName) - $(if ($on) { 'on' } else { 'off' })" } }
        $facts.Antivirus = ($av | ForEach-Object { $_.displayName }) -join ', '
        if (-not $av.Count) { Add-Finding 'High' 'Security' 'No antivirus registered with Windows Security Center.' }
    } catch { $rows += [pscustomobject]@{ Item = 'Antivirus'; Value = 'Security Center not available (server OS?)' } }
    try { foreach ($fp in @(Get-NetFirewallProfile -ErrorAction Stop)) { $rows += [pscustomobject]@{ Item = "Firewall $($fp.Name)"; Value = "$($fp.Enabled)" }; if (-not $fp.Enabled) { Add-Finding 'Medium' 'Security' "Windows Firewall $($fp.Name) profile is off." } } } catch { }
    $uac = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction SilentlyContinue).EnableLUA
    $rows += [pscustomobject]@{ Item = 'UAC'; Value = $(if ($uac -eq 0) { 'Off' } else { 'On' }) }
    if ($uac -eq 0) { Add-Finding 'High' 'Security' 'User Account Control is turned off.' }
    $rows
}
Invoke-Section 'Win11Readiness' {
    $os = Get-CimInstance Win32_OperatingSystem
    $sysDisk = Get-GB (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").Size
    $tpm2 = "$($facts.TPM)" -match 'version 2\.'
    $checks = @(
        [pscustomobject]@{ Check = 'TPM 2.0'; Result = $(if ($tpm2) { 'Pass' } elseif ("$($facts.TPM)" -match 'needs admin') { 'Unknown' } else { 'Fail' }); Value = $facts.TPM }
        [pscustomobject]@{ Check = 'Secure Boot capable'; Result = $(if ($facts.SecureBoot -match '^O(n|ff)$') { 'Pass' } else { 'Check' }); Value = $facts.SecureBoot }
        [pscustomobject]@{ Check = 'RAM >= 4 GB'; Result = $(if ($facts.RamGB -ge 4) { 'Pass' } else { 'Fail' }); Value = "$($facts.RamGB) GB" }
        [pscustomobject]@{ Check = 'System disk >= 64 GB'; Result = $(if ($sysDisk -ge 64) { 'Pass' } else { 'Fail' }); Value = "$sysDisk GB" }
        [pscustomobject]@{ Check = 'CPU on Microsoft supported list'; Result = 'Review'; Value = $facts.CPU }
    )
    if ($os.Caption -match 'Windows 10') {
        $fails = @($checks | Where-Object Result -eq 'Fail')
        $facts.Win11 = $(if ($fails.Count) { 'Not ready: ' + (($fails | ForEach-Object { $_.Check }) -join ', ') } else { 'Likely ready (confirm CPU)' })
        if ($fails.Count) { Add-Finding 'High' 'OS' "Cannot move to Windows 11 as is ($($facts.Win11)) - likely a replacement." }
    } else { $facts.Win11 = 'Already Windows 11 / server' }
    $checks
}
Invoke-Section 'Battery' {
    $bats = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
    if (-not $bats.Count) { return }
    $design = @(Get-CimInstance -Namespace root\wmi -ClassName BatteryStaticData -ErrorAction SilentlyContinue)
    $full = @(Get-CimInstance -Namespace root\wmi -ClassName BatteryFullChargedCapacity -ErrorAction SilentlyContinue)
    for ($i = 0; $i -lt [math]::Max($design.Count, 1); $i++) {
        $dc = if ($design.Count -gt $i) { $design[$i].DesignedCapacity } else { $null }; $fc = if ($full.Count -gt $i) { $full[$i].FullChargedCapacity } else { $null }
        $health = if ($dc -and $fc) { [math]::Round(100 * $fc / $dc, 0) } else { $null }
        if ($health -ne $null -and $health -lt 60) { Add-Finding 'Medium' 'Hardware' "Battery holds $health% of its original capacity - replacement recommended." }
        $facts.Battery = $(if ($health -ne $null) { "$health% of design" } else { 'present' })
        [pscustomobject]@{ Battery = $i; DesignmWh = $dc; FullChargemWh = $fc; HealthPct = $health; Status = $bats[0].Status }
    }
    if ($isAdmin) { try { & powercfg.exe /batteryreport /output (Join-Path $run 'battery-report.html') | Out-Null } catch { } }
}
Invoke-Section 'LocalAdmins' {
    $rows = @()
    try { $rows = @(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Type = "$($_.ObjectClass)"; Source = "$($_.PrincipalSource)" } }) }
    catch { $rows = @(& net.exe localgroup administrators | Select-Object -Skip 6 | Where-Object { $_ -and $_ -notmatch 'command completed' } | ForEach-Object { [pscustomobject]@{ Name = $_.Trim(); Type = ''; Source = 'net localgroup' } }) }
    $facts.LocalAdmins = $rows.Count
    $users = @($rows | Where-Object { $_.Type -eq 'User' -and $_.Name -notmatch '\\Administrator$' })
    if ($users.Count -gt 2) { Add-Finding 'Medium' 'Security' "$($users.Count) user accounts are local administrators - users should not be admins day to day." }
    $rows
}
Invoke-Section 'Profiles' {
    Get-CimInstance Win32_UserProfile -Filter 'Special=False' | ForEach-Object {
        $name = try { (New-Object Security.Principal.SecurityIdentifier($_.SID)).Translate([Security.Principal.NTAccount]).Value } catch { $_.SID }
        [pscustomobject]@{ Account = $name; Path = $_.LocalPath; LastUse = $_.LastUseTime; Loaded = $_.Loaded }
    }
}
Invoke-Section 'Software' {
    $keys = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    $sw = @(Get-ItemProperty $keys -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -and -not $_.SystemComponent -and -not $_.ParentKeyName } |
        Sort-Object DisplayName -Unique | ForEach-Object { [pscustomobject]@{ Name = $_.DisplayName; Version = $_.DisplayVersion; Publisher = $_.Publisher; Installed = $_.InstallDate } })
    $facts.SoftwareCount = $sw.Count
    $flag = $sw | Where-Object { $_.Name -match '(?i)skype for business|teamviewer|anydesk|ultraviewer|logmein|ammyy|utorrent|bittorrent|java 8|adobe flash|winrar' }
    foreach ($f in $flag) { Add-Finding 'Low' 'Software' "Review: $($f.Name) $($f.Version) installed." }
    $sw
}
Invoke-Section 'Startup' { Get-CimInstance Win32_StartupCommand | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Command = $_.Command; Location = $_.Location; User = $_.User } } }
Invoke-Section 'Services' {
    $stopped = @(Get-CimInstance Win32_Service -Filter "StartMode='Auto' AND State<>'Running'" | Where-Object { $_.Name -notmatch '^(gupdate|edgeupdate|MapsBroker|sppsvc|RemoteRegistry|WbioSrvc|TrustedInstaller|tiledatamodelsvc|GoogleUpdater|BITS|wuauserv|CDPSvc|dmwappushservice|ShellHWDetection|DoSvc|UsoSvc)' })
    $stopped | ForEach-Object { [pscustomobject]@{ Name = $_.Name; DisplayName = $_.DisplayName; State = $_.State; Account = $_.StartName } }
}
Invoke-Section 'Events' {
    $since = (Get-Date).AddDays(-$EventDays)
    $ev = @()
    foreach ($ln in 'System', 'Application') { try { $ev += @(Get-WinEvent -FilterHashtable @{ LogName = $ln; Level = 1, 2; StartTime = $since } -MaxEvents 2000 -ErrorAction Stop) } catch { } }
    $facts.ErrorEvents = $ev.Count
    foreach ($bad in @($ev | Where-Object { $_.ProviderName -match 'disk|Ntfs|storahci|stornvme|iaStor' -and $_.LogName -eq 'System' })) { if (-not $facts.DiskEvt) { $facts.DiskEvt = $true; Add-Finding 'High' 'Disk' ("Disk/file-system errors in the System log in the last {0} days ({1} id {2}: {3}) - check that drive (a USB drive being unplugged also logs these)." -f $EventDays, $bad.ProviderName, $bad.Id, (("$($bad.Message)" -split "`n")[0].Trim())) } }
    $kp = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41 })
    if ($kp.Count) { Add-Finding 'Medium' 'Stability' "$($kp.Count) unexpected shutdown(s) / power loss (Kernel-Power 41) in the last $EventDays days." }
    $ev | Group-Object LogName, ProviderName, Id | Sort-Object Count -Descending | Select-Object -First 40 | ForEach-Object {
        $f = $_.Group[0]; [pscustomobject]@{ Log = $f.LogName; Source = $f.ProviderName; Id = $f.Id; Level = $f.LevelDisplayName; Count = $_.Count; Last = ($_.Group | Sort-Object TimeCreated -Descending)[0].TimeCreated; Sample = ("$($f.Message)" -split "`n")[0] } }
}
Invoke-Section 'Crashes' {
    $since = (Get-Date).AddDays(-$CrashDays)
    $c = @(); try { $c = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = 'Application Error', 'Windows Error Reporting'; StartTime = $since } -MaxEvents 1000 -ErrorAction Stop | Where-Object { $_.Id -in 1000, 1001 }) } catch { }
    $bsod = @(); try { $bsod = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-WER-SystemErrorReporting'; StartTime = $since } -ErrorAction Stop) } catch { }
    if ($bsod.Count) { Add-Finding 'High' 'Stability' "$($bsod.Count) blue-screen crash(es) in the last $CrashDays days." }
    $apps = $c | Where-Object { $_.Id -eq 1000 } | ForEach-Object { ("$($_.Message)" -split "`n")[0] -replace '^Faulting application name:\s*', '' -replace ',.*$', '' } | Group-Object | Sort-Object Count -Descending
    $out = @($apps | ForEach-Object { [pscustomobject]@{ Kind = 'App crash'; Name = $_.Name; Count = $_.Count } })
    $out += @($bsod | ForEach-Object { [pscustomobject]@{ Kind = 'Blue screen'; Name = $_.TimeCreated; Count = 1 } })
    $out
}
Invoke-Section 'Network' {
    Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' | ForEach-Object {
        $a = Get-CimInstance Win32_NetworkAdapter -Filter "Index=$($_.Index)"
        [pscustomobject]@{ Adapter = $_.Description; Connection = $a.NetConnectionID; SpeedMbps = $(if ($a.Speed) { [math]::Round($a.Speed / 1e6) }); MAC = $_.MACAddress; DHCP = $_.DHCPEnabled
            IPv4 = (@($_.IPAddress | Where-Object { $_ -match '^\d+\.' }) -join ' '); Gateway = ($_.DefaultIPGateway -join ' '); DNS = ($_.DNSServerSearchOrder -join ' '); DnsSuffix = $_.DNSDomain }
    }
}
Invoke-Section 'Updates' {
    $hf = @(Get-HotFix -ErrorAction SilentlyContinue | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending)
    $last = if ($hf.Count) { $hf[0].InstalledOn } else { $null }
    $facts.LastPatch = $last
    if ($last -and ((Get-Date) - $last).TotalDays -gt 45) { Add-Finding 'High' 'Updates' ("Last Windows update installed {0:yyyy-MM-dd} ({1:N0} days ago) - updates are not being applied." -f $last, ((Get-Date) - $last).TotalDays) }
    $pending = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
    $facts.PendingReboot = $pending
    if ($pending) { Add-Finding 'Low' 'Updates' 'A restart is pending to finish installing updates.' }
    $hf | Select-Object -First 25 | ForEach-Object { [pscustomobject]@{ KB = $_.HotFixID; Description = $_.Description; InstalledOn = $_.InstalledOn } }
}
Invoke-Section 'Printers' { Get-CimInstance Win32_Printer | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Driver = $_.DriverName; Port = $_.PortName; Shared = $_.Shared; Default = $_.Default; Network = $_.Network } } }
Invoke-Section 'Shares' { Get-CimInstance Win32_Share | Where-Object { $_.Name -notmatch '\$$' } | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Path = $_.Path; Description = $_.Description } } }

# ---- summary
$order = @{ High = 0; Medium = 1; Low = 2 }
$sorted = @($findings | Sort-Object { $order[$_.Severity] }, Area)
$sorted | Export-Csv (Join-Path $run 'Findings.csv') -NoTypeInformation
$results | Export-Csv (Join-Path $run 'Results.csv') -NoTypeInformation
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("DTS endpoint assessment - $env:COMPUTERNAME - $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
$lines.Add(('Elevated: {0}' -f $isAdmin)); $lines.Add('')
foreach ($k in 'Make', 'Model', 'Serial', 'Chassis', 'ApproxAgeYears', 'Domain', 'OS', 'CPU', 'RamGB', 'SystemDriveFreePct', 'BitLocker', 'TPM', 'SecureBoot', 'Defender', 'Antivirus', 'Battery', 'Win11', 'LastPatch', 'LastBoot', 'PendingReboot', 'LocalAdmins', 'SoftwareCount', 'ErrorEvents') {
    if ($facts.Contains($k)) { $lines.Add(('{0,-20} {1}' -f $k, $facts[$k])) }
}
$lines.Add(''); $lines.Add("Findings ($($sorted.Count)):")
if (-not $sorted.Count) { $lines.Add('  none') } else { foreach ($f in $sorted) { $lines.Add(('  [{0}] {1}: {2}' -f $f.Severity, $f.Area, $f.Finding)) } }
$bad = @($results | Where-Object { $_.Status -ne 'Collected' })
if ($bad.Count) { $lines.Add(''); $lines.Add('Sections not collected:'); foreach ($b in $bad) { $lines.Add(('  {0}: {1} {2}' -f $b.Section, $b.Status, $b.Detail)) } }
$lines | Set-Content (Join-Path $run 'Summary.txt') -Encoding ASCII
$log | Export-Csv (Join-Path $run 'Log.csv') -NoTypeInformation
$zip = "$run.zip"
try { Compress-Archive -Path (Join-Path $run '*') -DestinationPath $zip -Force; Write-Step 'Zip' 'OK' $zip } catch { Write-Step 'Zip' 'Error' $_.Exception.Message }
Write-Host ''
$lines | ForEach-Object { Write-Host $_ }
Write-Host ''
Write-Host "Folder: $run" -ForegroundColor Green
