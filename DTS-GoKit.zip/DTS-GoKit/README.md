# DTS Go kit

Tools Diligent Technology Solutions uses on a Windows machine it supports. Double-click **Go.cmd** (it asks
for administrator rights) and pick from the menu.

| Choice | What it does | Changes the machine? |
|---|---|---|
| 1. Install Splashtop | Opens the Splashtop download for DTS remote support | Installs Splashtop when you run the download |
| 2. Hardware assessment | Reads hardware, health and security settings; writes a report folder and zip under `Output\` | No - read-only |
| 3. Give Bench access | Temporary support access for DTS's automation (see below) | Yes, until it ends |
| 4. Extend Bench access | Moves the end time | Only the end time |
| 5. End Bench access now | Removes everything choice 3 added | Undoes choice 3 |

## Bench access - what it adds and how it goes away

- A local administrator account `dts-bench` (random password nobody sees; sign-in by key only).
- OpenSSH Server (a Windows feature), reachable **only** through DTS's private Tailscale network.
- Tailscale, joined with a one-time key. This machine cannot reach anything on DTS's network; DNS and routes
  on this machine are not changed.
- A record of every PowerShell command run during the session, in `C:\ProgramData\DTS\BenchAccess\Transcripts`.

At the end time (default 4 hours) a scheduled task removes all of it - account, profile, OpenSSH (if it was
added), Tailscale, firewall rule, settings - and writes the result to the Windows Application event log
(source `DTSBenchAccess`). If the machine is off at the end time, the cleanup runs when it next starts.
The session record is kept in `C:\ProgramData\DTS\BenchAccess`.

## Files

`Go.cmd`, `Go.ps1` (menu), `Collect-EndpointAssessment.ps1`, `Start-BenchAccess.ps1`, `Stop-BenchAccess.ps1`.
`SHA256SUMS.txt` lists each file's SHA-256. All scripts run on Windows PowerShell 5.1 or later.
