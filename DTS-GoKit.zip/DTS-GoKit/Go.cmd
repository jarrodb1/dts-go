@echo off
rem DTS Go kit launcher: asks for admin rights, then opens the Go menu (Go.ps1) from this folder.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Go.ps1"
