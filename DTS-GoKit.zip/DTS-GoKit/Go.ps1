<#
.SYNOPSIS
    DTS Go kit menu: Splashtop install link, hardware assessment, start / extend / end Bench access.

.DESCRIPTION
    WINDOWS POWERSHELL 5.1 COMPATIBLE. Started by Go.cmd (which elevates). Each choice runs the matching script
    from this folder; nothing runs without a choice. Splashtop: opens the deployment link stored in
    splashtop-link.txt next to this script - that file is only on Jarrod's stick (Build-GoKit.ps1
    -IncludeSplashtopLink), never in git or a public download. Without that file it asks for an unlock code
    (1Password 'Go kit unlock code') and gets the link from the DTS unlock service (Unlock.ps1).

.EXAMPLE
    Double-click Go.cmd on the stick, or: powershell -ExecutionPolicy Bypass -File .\Go.ps1

.NOTES
    DTS Go kit (Projects\GoStick\README.md). Written 2026-11-16. Changes nothing itself (menu only).
#>
[CmdletBinding()]
param()
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$unlockHelper = Join-Path $here 'Unlock.ps1'
if (Test-Path $unlockHelper) { . $unlockHelper }
function Invoke-Kit([string]$Script, [hashtable]$Params = @{}) {
    $p = Join-Path $here $Script
    if (-not (Test-Path $p)) { Write-Host "  $Script is missing from the kit." -ForegroundColor Red; return }
    try { & $p @Params } catch { Write-Host "  $($_.Exception.Message)" -ForegroundColor Red }
}
while ($true) {
    $active = Test-Path 'C:\ProgramData\DTS\BenchAccess\state.json'
    Write-Host ''
    Write-Host '  ===== DTS Go kit =====' -ForegroundColor Cyan
    Write-Host "  Machine: $env:COMPUTERNAME$(if ($active) { '   [Bench access ACTIVE]' })"
    Write-Host '  1. Install Splashtop (Diligent Technology remote support)'
    Write-Host '  2. Hardware assessment (read-only)'
    Write-Host '  3. Give Bench access (temporary)'
    Write-Host '  4. Extend Bench access'
    Write-Host '  5. End Bench access now'
    Write-Host '  6. Give Bench PERMANENT access (no Tailscale yet: installs it with a key from Bench; or already on a DTS-managed tailnet)'
    Write-Host '  Q. Quit'
    $c = Read-Host '  Choose'
    switch ($c.Trim().ToUpper()) {
        '1' {
            $f = Join-Path $here 'splashtop-link.txt'
            if (Test-Path $f) { $u = (Get-Content $f | Where-Object { $_ -match '^https://' } | Select-Object -First 1); if ($u) { Start-Process $u; Write-Host '  Opened the Splashtop download in the browser - run the installer it downloads.' } else { Write-Host '  splashtop-link.txt has no https:// link.' -ForegroundColor Red } }
            elseif (Get-Command Invoke-GoKitUnlock -ErrorAction SilentlyContinue) {
                try { $code = Read-GoKitUnlockCode; $r = Invoke-GoKitUnlock -Code $code -Want splashtop; $code = $null
                      if ("$($r.splashtopLink)" -match '^https://') { Start-Process $r.splashtopLink; Write-Host '  Opened the Splashtop download in the browser - run the installer it downloads.' } else { Write-Host '  The unlock service returned no Splashtop link.' -ForegroundColor Red } }
                catch { Write-Host "  $($_.Exception.Message)" -ForegroundColor Red }
            }
            else { Write-Host '  No Splashtop link on this copy of the kit, and Unlock.ps1 is missing.' -ForegroundColor Yellow }
        }
        '2' { Invoke-Kit 'Collect-EndpointAssessment.ps1' }
        '3' { $h = Read-Host '  Hours (1-24, Enter = 4)'; if (-not $h) { $h = '4' }; Invoke-Kit 'Start-BenchAccess.ps1' @{ Hours = [int]($h -replace '\D', '') } }
        '4' { $h = Read-Host '  Add how many hours (1-24)'; if ($h) { Invoke-Kit 'Start-BenchAccess.ps1' @{ ExtendHours = [int]($h -replace '\D', '') } } }
        '5' { $s = 'C:\ProgramData\DTS\BenchAccess\Stop-BenchAccess.ps1'; if (Test-Path $s) { & $s } else { Invoke-Kit 'Stop-BenchAccess.ps1' } }
        '6' { $ok = Read-Host '  Permanent access stays until removed by hand. Type PERMANENT to continue'; if ($ok -ceq 'PERMANENT') { Invoke-Kit 'Start-BenchAccess.ps1' @{ Permanent = $true } } else { Write-Host '  Cancelled - nothing changed.' } }
        'Q' { return }
        default { Write-Host '  Pick 1-6 or Q.' }
    }
}
