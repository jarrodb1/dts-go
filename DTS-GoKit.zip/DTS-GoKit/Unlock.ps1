<#
.SYNOPSIS
    Go kit helper: trades a 6-digit unlock code (1Password 'Go kit unlock code' on Jarrod's phone) for a one-use
    Tailscale key and/or the Splashtop link, from the DTS unlock service.

.EXAMPLE
    . .\Unlock.ps1; $r = Invoke-GoKitUnlock -Code 123456 -Want tailscale
    $r.tailscaleKey holds a one-use key (1 hour, tag:customer-temp). Nothing is written to disk.

.NOTES
    WINDOWS POWERSHELL 5.1 COMPATIBLE, ASCII. DTS Go kit (Projects\GoStick\README.md). Written 2026-11-17 (Bench).
    Dot-sourced by Go.ps1 and Start-BenchAccess.ps1; defines functions only, changes nothing. No secrets here:
    the service URL is public; the code is the only credential and works once.
#>
$script:GoKitUnlockUrl = 'https://dts-gokit-unlock.azurewebsites.net/api/unlock'

function Invoke-GoKitUnlock {
    param([Parameter(Mandatory = $true)][string] $Code, [string[]] $Want = @('tailscale'))
    if ($Code -notmatch '^\s*\d{3}\s?\d{3}\s*$') { throw 'An unlock code is 6 digits.' }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $body = @{ code = ($Code -replace '\s', ''); want = $Want; host = $env:COMPUTERNAME } | ConvertTo-Json
    try { return Invoke-RestMethod -Method Post -Uri $script:GoKitUnlockUrl -ContentType 'application/json' -Body $body -TimeoutSec 60 }
    catch {
        $msg = $null
        try { $msg = ($_.ErrorDetails.Message | ConvertFrom-Json).error } catch { }
        if (-not $msg) { $msg = $_.Exception.Message }
        throw "Unlock refused: $msg"
    }
}

function Read-GoKitUnlockCode([string] $Prompt = 'Unlock code (6 digits, 1Password "Go kit unlock code")') {
    $c = Read-Host "  $Prompt"
    return "$c".Trim()
}
