<#
.SYNOPSIS
    Ends Bench's temporary access on this machine: undoes exactly what Start-BenchAccess.ps1 recorded in
    state.json, then removes the cleanup task. Keeps the session record (transcripts + logs).

.DESCRIPTION
    WINDOWS POWERSHELL 5.1 COMPATIBLE. Runs as SYSTEM from the cleanup task at expiry, or elevated by hand to end
    early. Order: Tailscale off the tailnet and uninstalled (if we installed it); SSH firewall rule removed
    (default OpenSSH rule re-enabled if we disabled it); Bench's key removed; OpenSSH Server removed if we
    installed it (else its service put back as it was); SSH default shell and transcription policy restored;
    the dts-bench user and its profile deleted; cleanup task deleted; state.json renamed state-ended-<stamp>.json.
    Each step has its own try/catch - one failure never stops the rest. Result in the Application event log
    (source DTSBenchAccess, 200 = removed cleanly, 201 = removed with errors) and Output\BenchAccessStop-*.csv.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File C:\ProgramData\DTS\BenchAccess\Stop-BenchAccess.ps1
    Ends access now.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Stop-BenchAccess.ps1 -WhatIf
    Shows what would be undone.

.NOTES
    DTS Go kit (Projects\GoStick\README.md). Written 2026-11-16. Kept after cleanup:
    C:\ProgramData\DTS\BenchAccess\Transcripts and \Output (the record of what Bench did).
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $Root = 'C:\ProgramData\DTS\BenchAccess',
    [string] $Reason = 'Manual',
    [string] $KeyMarker = 'dts-bench-field'
)
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$statePath = Join-Path $Root 'state.json'
$outDir = Join-Path $Root 'Output'
$results = New-Object System.Collections.Generic.List[object]
$log = New-Object System.Collections.Generic.List[object]
$errors = 0
$evtSource = 'DTSBenchAccess'
function Write-Step([string]$Step, [string]$Level, [string]$Message) {
    $log.Add([pscustomobject]@{ Time = (Get-Date -Format 's'); Step = $Step; Level = $Level; Message = $Message })
    Write-Host ('  {0,-10} {1,-6} {2}' -f $Step, $Level, $Message)
}
function Invoke-Undo([string]$Item, [scriptblock]$Do) {
    try { if ($PSCmdlet.ShouldProcess($env:COMPUTERNAME, "undo: $Item")) { $d = & $Do; Write-Step $Item 'OK' "$d"; $results.Add([pscustomobject]@{ Item = $Item; Outcome = 'OK'; Detail = "$d" }) } }
    catch { $script:errors++; Write-Step $Item 'Error' $_.Exception.Message; $results.Add([pscustomobject]@{ Item = $Item; Outcome = 'Error'; Detail = $_.Exception.Message }) }
}

if (-not (Test-Path $statePath)) { Write-Host 'No active Bench access on this machine (no state.json). Nothing to do.'; return }
$s = Get-Content $statePath -Raw | ConvertFrom-Json
Write-Host "Ending DTS Bench access (reason: $Reason; started $($s.Started) by $($s.StartedBy))" -ForegroundColor Cyan

if ($s.TailscaleInstalled) {
    Invoke-Undo 'Tailscale' {
        $ts = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
        if (Test-Path $ts) { & $ts logout 2>&1 | Out-Null }
        $keys = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
        $prod = @(Get-ItemProperty $keys -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'Tailscale*' -and $_.PSChildName -match '^\{' })
        foreach ($p in $prod) { $r = Start-Process msiexec.exe -ArgumentList "/x $($p.PSChildName) /qn /norestart" -Wait -PassThru; if ($r.ExitCode -notin 0, 3010, 1605) { throw "uninstall exit $($r.ExitCode)" } }
        "logged out, uninstalled ($($prod.Count) product)"
    }
}
if ($s.FirewallRule) { Invoke-Undo 'Firewall' { Remove-NetFirewallRule -Group 'DTS Bench Access' -ErrorAction SilentlyContinue; 'rule removed' } }
if ($s.DefaultRuleDisabled) { Invoke-Undo 'FwDefault' { Enable-NetFirewallRule -Name 'OpenSSH-Server-In-TCP'; 'default OpenSSH rule re-enabled' } }
if ($s.KeyAdded) {
    Invoke-Undo 'Key' {
        $akf = Join-Path $env:ProgramData 'ssh\administrators_authorized_keys'
        if (Test-Path $akf) {
            $keep = @(Get-Content $akf | Where-Object { $_ -notmatch [regex]::Escape($KeyMarker) })
            if ($s.KeyFileCreated -and -not @($keep | Where-Object { $_.Trim() }).Count) { Remove-Item $akf -Force; 'key file removed (we created it)' }
            else { Set-Content -Path $akf -Value $keep -Encoding ASCII; "key removed; $(@($keep | Where-Object { $_.Trim() }).Count) other key(s) kept" }
        } else { 'key file already gone' }
    }
}
Invoke-Undo 'Sessions' {
    $n = 0
    foreach ($p in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
        $o = $null; try { $o = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction Stop } catch { }
        if ($o -and $o.User -eq $s.UserName) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; $n++ } catch { } }
    }
    "$n process(es) of $($s.UserName) ended"
}
if ($s.SshdInstalled) {
    Invoke-Undo 'OpenSSH' {
        Stop-Service sshd -Force -ErrorAction SilentlyContinue; Set-Service sshd -StartupType Disabled -ErrorAction SilentlyContinue
        $cap = @(Get-WindowsCapability -Online | Where-Object { $_.Name -like 'OpenSSH.Server*' -and $_.State -eq 'Installed' })
        foreach ($c in $cap) { Remove-WindowsCapability -Online -Name $c.Name | Out-Null }
        'OpenSSH Server removed (we installed it)'
    }
} elseif ($s.SshdPreexisting) {
    Invoke-Undo 'OpenSSH' {
        $mode = switch ($s.SshdStartType) { 'Auto' { 'Automatic' } 'Manual' { 'Manual' } 'Disabled' { 'Disabled' } default { 'Manual' } }
        Set-Service sshd -StartupType $mode
        if ($s.SshdStatus -ne 'Running') { Stop-Service sshd -Force -ErrorAction SilentlyContinue }
        "sshd put back: $mode, $($s.SshdStatus)"
    }
}
if ($s.DefaultShellSet) {
    Invoke-Undo 'Shell' {
        if ($s.DefaultShellOld) { New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value $s.DefaultShellOld -PropertyType String -Force | Out-Null; 'default shell restored' }
        else { Remove-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -ErrorAction SilentlyContinue; 'default shell value removed' }
    }
}
if ($s.TranscriptionSet) {
    Invoke-Undo 'Record' {
        $tk = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription'
        Remove-ItemProperty -Path $tk -Name EnableTranscripting, EnableInvocationHeader, OutputDirectory -ErrorAction SilentlyContinue
        if (-not @((Get-Item $tk -ErrorAction SilentlyContinue).Property).Count) { Remove-Item $tk -ErrorAction SilentlyContinue }
        'transcription policy removed (transcripts kept)'
    }
}
if ($s.UserCreated) {
    Invoke-Undo 'User' {
        $u = Get-LocalUser -Name $s.UserName -ErrorAction SilentlyContinue
        if ($u -and $u.SID.Value -eq $s.UserSid) { Remove-LocalUser -SID $s.UserSid }
        $prof = @(Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue | Where-Object { $_.SID -eq $s.UserSid })
        foreach ($p in $prof) { try { Remove-CimInstance -InputObject $p -ErrorAction Stop } catch { throw "user removed; profile $($p.LocalPath) in use - delete at next restart ($($_.Exception.Message))" } }
        "user $($s.UserName) and $($prof.Count) profile(s) removed"
    }
}
Invoke-Undo 'Task' {
    $tn = [string]$s.TaskName; $path = $tn.Substring(0, $tn.LastIndexOf('\') + 1); $name = $tn.Substring($tn.LastIndexOf('\') + 1)
    Unregister-ScheduledTask -TaskName $name -TaskPath $path -Confirm:$false -ErrorAction SilentlyContinue; 'cleanup task removed'
}
if (-not $WhatIfPreference) {
    try { Rename-Item $statePath ("state-ended-$stamp.json") -Force } catch { $errors++ }
    $msg = "Bench (DTS) access ended ($Reason). {0} step(s), {1} error(s). Record kept in {2}." -f $results.Count, $errors, $Root
    try { if (-not [System.Diagnostics.EventLog]::SourceExists($evtSource)) { New-EventLog -LogName Application -Source $evtSource }
          Write-EventLog -LogName Application -Source $evtSource -EventId $(if ($errors) { 201 } else { 200 }) -EntryType $(if ($errors) { 'Warning' } else { 'Information' }) -Message $msg } catch { }
    try { if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
          $results | Export-Csv (Join-Path $outDir "BenchAccessStop-$stamp-Results.csv") -NoTypeInformation
          $log | Export-Csv (Join-Path $outDir "BenchAccessStop-$stamp-Log.csv") -NoTypeInformation } catch { }
    Write-Host $msg -ForegroundColor $(if ($errors) { 'Yellow' } else { 'Green' })
}
