<#
.SYNOPSIS
    Gives Bench (Claude Code on Jarrod's T14) temporary SSH access to this Windows machine over Tailscale,
    and schedules its own removal. Nothing stays after the cleanup except the session record.

.DESCRIPTION
    WINDOWS POWERSHELL 5.1 COMPATIBLE (customer machines). Run elevated, on the customer machine, by Jarrod
    (usually over Splashtop). Steps, each recorded in state.json so Stop-BenchAccess.ps1 undoes exactly what
    this run changed:
      1. Pre-checks: admin, 64-bit Windows, no Tailscale already on the machine (it could be the customer's
         own tailnet - refuse), no active Bench access.
      2. Cleanup task first: '\DTS\DTS Bench Access Cleanup' (SYSTEM, at expiry; runs at next start if the
         machine was off) -> Stop-BenchAccess.ps1. So even a half-finished run gets removed.
      3. Local admin 'dts-bench' with a random password nobody sees (key sign-in only).
      4. OpenSSH Server (Windows feature) if not present; password sign-in off when we installed it.
      5. Bench's public key in administrators_authorized_keys.
      6. Firewall: SSH (22) allowed only from Tailscale addresses (100.64.0.0/10).
      7. PowerShell as the SSH shell, and PowerShell transcription to C:\ProgramData\DTS\BenchAccess\Transcripts
         for the window (only if the machine has no transcription policy of its own).
      8. Tailscale (signed MSI, checked) joined with a one-time, ephemeral, tag:customer-temp key. DNS and routes
         from the tailnet are NOT accepted. The tailnet policy lets only Bench reach this machine, port 22;
         this machine can reach nothing on the tailnet.
    Output: C:\ProgramData\DTS\BenchAccess\Output\BenchAccess-<stamp>-Results.csv / -Log.csv. Event log:
    Application, source DTSBenchAccess.

.PARAMETER Hours
    How long access lasts (1-24). Default 4.

.PARAMETER AuthKey
    Tailscale auth key (ephemeral, tagged tag:customer-temp). If not given, asks for a 6-digit unlock code
    (1Password 'Go kit unlock code'; the DTS unlock service returns a one-use key - Unlock.ps1) or a pasted key.

.PARAMETER ExtendHours
    Only extends an active session's expiry by this many hours; changes nothing else.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Start-BenchAccess.ps1 -Hours 4
    Prompts for the Tailscale key, sets everything up, prints the address for Bench.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Start-BenchAccess.ps1 -WhatIf
    Pre-checks only; changes nothing.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Start-BenchAccess.ps1 -ExtendHours 2

.NOTES
    DTS Go kit (Projects\GoStick\README.md). Written 2026-11-16 (Bench, Jarrod's go). Rollback / early end:
    Stop-BenchAccess.ps1 (also what the cleanup task runs). No secrets in this file: the SSH key below is the
    PUBLIC half of the T14's dts_field key; the Tailscale key is typed in at run time and never stored.
    Used only with the machine owner's approval (DTS policy).
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateRange(1, 24)][int] $Hours = 4,
    [string] $AuthKey,
    [ValidateRange(1, 24)][int] $ExtendHours,
    [string] $PublicKey = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHmtMyzInaMPs3rR2YcrRFz34wfBthUUb90YZcKf2joi dts-bench-field (T14, customer machines only)',
    [string] $UserName = 'dts-bench',
    [string] $Root = 'C:\ProgramData\DTS\BenchAccess',
    [string] $TailscaleMsiUrl,
    [string] $TaskName = 'DTS Bench Access Cleanup',
    [string] $TaskPath = '\DTS\',
    [string] $SshAllowFrom = '100.64.0.0/10'
)
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outDir = Join-Path $Root 'Output'
$statePath = Join-Path $Root 'state.json'
$results = New-Object System.Collections.Generic.List[object]
$log = New-Object System.Collections.Generic.List[object]
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$fwName = 'DTS Bench Access - SSH from Tailscale only'
$evtSource = 'DTSBenchAccess'

function Write-Step([string]$Step, [string]$Level, [string]$Message) {
    $log.Add([pscustomobject]@{ Time = (Get-Date -Format 's'); Step = $Step; Level = $Level; Message = $Message })
    $color = switch ($Level) { 'Error' { 'Red' } 'Stop' { 'Red' } 'Warn' { 'Yellow' } 'OK' { 'Green' } default { 'Gray' } }
    Write-Host ('  {0,-10} {1,-6} {2}' -f $Step, $Level, $Message) -ForegroundColor $color
}
function Add-Result([string]$Item, [string]$Outcome, [string]$Detail) { $results.Add([pscustomobject]@{ Time = (Get-Date -Format 's'); Item = $Item; Outcome = $Outcome; Detail = $Detail }) }
function Save-State($s) { if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root -Force -WhatIf:$false | Out-Null }; ($s | ConvertTo-Json -Depth 5) | Set-Content -Path $statePath -Encoding ASCII -WhatIf:$false }
function Write-Evt([int]$Id, [string]$Msg, [string]$Type = 'Information') {
    try { if (-not [System.Diagnostics.EventLog]::SourceExists($evtSource)) { New-EventLog -LogName Application -Source $evtSource -WhatIf:$false }
          Write-EventLog -LogName Application -Source $evtSource -EventId $Id -EntryType $Type -Message $Msg -WhatIf:$false } catch { }
}
function Save-Logs {
    try { if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force -WhatIf:$false | Out-Null }
          $results | Export-Csv (Join-Path $outDir "BenchAccess-$stamp-Results.csv") -NoTypeInformation -WhatIf:$false
          $log | Export-Csv (Join-Path $outDir "BenchAccess-$stamp-Log.csv") -NoTypeInformation -WhatIf:$false } catch { Write-Host "  could not write logs: $($_.Exception.Message)" }
}
function Set-CleanupTask([datetime]$At) {
    $stop = Join-Path $Root 'Stop-BenchAccess.ps1'
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -File "{0}" -Reason Expired' -f $stop)
    $trigger = New-ScheduledTaskTrigger -Once -At $At
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    $principal = New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -LogonType ServiceAccount -RunLevel Highest
    Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
}

$state = $null
$failed = $false
try {
    Write-Host ''
    Write-Host 'DTS Bench access - temporary, removes itself' -ForegroundColor Cyan
    # ---- pre-checks
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this from an elevated (Run as administrator) PowerShell.' }
    if (-not [Environment]::Is64BitOperatingSystem) { throw '32-bit Windows is not supported.' }
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'arm64' } else { 'amd64' }
    if (-not $TailscaleMsiUrl) { $TailscaleMsiUrl = "https://pkgs.tailscale.com/stable/tailscale-setup-latest-$arch.msi" }
    Write-Step 'Machine' 'INFO' ("{0}, {1}, PowerShell {2}" -f $env:COMPUTERNAME, $arch, $PSVersionTable.PSVersion)

    $old = $null; if (Test-Path $statePath) { $old = Get-Content $statePath -Raw | ConvertFrom-Json }
    if ($ExtendHours) {
        if (-not $old) { throw 'No active Bench access to extend.' }
        $newExp = ([datetime]$old.Expires).AddHours($ExtendHours)
        if ($PSCmdlet.ShouldProcess($env:COMPUTERNAME, "extend Bench access to $newExp")) {
            Set-CleanupTask $newExp
            $old.Expires = $newExp.ToString('s'); Save-State $old
            Write-Step 'Extend' 'OK' "access now ends $newExp"; Add-Result 'Extend' 'OK' $newExp.ToString('s')
            Write-Evt 101 "Bench access extended to $newExp by $($id.Name)."
        }
        return
    }
    if ($old) { throw "Bench access is already active (ends $($old.Expires)). Use -ExtendHours, or Stop-BenchAccess.ps1 first." }
    if (Get-Service -Name 'Tailscale' -ErrorAction SilentlyContinue) { throw 'Tailscale is already installed on this machine (possibly the customer''s own tailnet). Stopping - nothing changed.' }
    if (Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue) { throw "A local user '$UserName' already exists. Stopping - nothing changed." }
    if (-not (Test-Path (Join-Path $scriptDir 'Stop-BenchAccess.ps1'))) { throw 'Stop-BenchAccess.ps1 must be next to this script.' }
    Write-Step 'Checks' 'OK' 'admin, 64-bit, no Tailscale, no existing dts-bench user, no active session'

    $expires = (Get-Date).AddHours($Hours)
    if (-not $PSCmdlet.ShouldProcess($env:COMPUTERNAME, "give Bench SSH access over Tailscale until $expires")) { Write-Step 'WhatIf' 'INFO' 'pre-checks passed; nothing changed'; return }

    # Up to 3 tries. The code is typed visibly (it works once, so showing it is harmless); a pasted key is used as is.
    for ($try = 1; -not $AuthKey -and $try -le 3; $try++) {
        $in = "$(Read-Host '  Unlock code (6 digits from 1Password "Go kit unlock code") - or paste a Tailscale key')".Trim()
        $digits = $in -replace '[\s-]', ''
        if ($in -match '^tskey-auth-') { $AuthKey = $in }
        elseif ($digits -match '^\d{6}$') {
            $helper = Join-Path $scriptDir 'Unlock.ps1'
            if (-not (Test-Path $helper)) { throw 'Unlock.ps1 is missing from the kit - paste a Tailscale key instead.' }
            . $helper
            try { $AuthKey = (Invoke-GoKitUnlock -Code $digits -Want tailscale).tailscaleKey; Write-Step 'Unlock' 'OK' 'one-use Tailscale key received from the DTS unlock service' }
            catch { Write-Step 'Unlock' 'Warn' "$($_.Exception.Message)" }
        }
        else { Write-Step 'Unlock' 'Warn' ("expected 6 digits or a tskey-auth- key; got {0} characters - try again" -f $in.Length) }
        $in = $null
    }
    if (-not $AuthKey) { throw 'No Tailscale key after 3 tries - nothing was changed.' }
    if ($AuthKey -notmatch '^tskey-auth-') { throw 'That does not look like a Tailscale auth key (tskey-auth-...).' }

    $state = [ordered]@{ Version = 1; Started = (Get-Date).ToString('s'); Expires = $expires.ToString('s'); StartedBy = $id.Name
        UserName = $UserName; UserSid = ''; UserCreated = $false; SshdInstalled = $false; SshdPreexisting = $false; SshdStartType = ''; SshdStatus = ''
        PasswordAuthOff = $false; KeyAdded = $false; KeyFileCreated = $false; FirewallRule = $false; DefaultRuleDisabled = $false
        DefaultShellSet = $false; DefaultShellOld = $null; TranscriptionSet = $false; TailscaleInstalled = $false; TailscaleIp = ''; TaskName = ($TaskPath + $TaskName) }
    New-Item -ItemType Directory -Path (Join-Path $Root 'Transcripts') -Force | Out-Null
    Save-State $state

    # ---- 2. cleanup task first
    Copy-Item (Join-Path $scriptDir 'Stop-BenchAccess.ps1') (Join-Path $Root 'Stop-BenchAccess.ps1') -Force
    Set-CleanupTask $expires
    Write-Step 'Cleanup' 'OK' "task $TaskPath$TaskName (SYSTEM) at $expires"; Add-Result 'CleanupTask' 'OK' $expires.ToString('s')

    # ---- 3. local admin, random password nobody sees
    $chars = [char[]]'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!#%+=?'
    $bytes = New-Object byte[] 40; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $pw = -join ($bytes | ForEach-Object { $chars[$_ % $chars.Length] })
    $secPw = ConvertTo-SecureString $pw -AsPlainText -Force; $pw = $null
    $u = New-LocalUser -Name $UserName -Password $secPw -PasswordNeverExpires -AccountNeverExpires -FullName 'DTS Bench (temporary)' -Description ("DTS access, removed {0:yyyy-MM-dd HH:mm}" -f $expires)
    $secPw = $null
    $state.UserCreated = $true; $state.UserSid = $u.SID.Value; Save-State $state
    $admins = Get-LocalGroup -SID 'S-1-5-32-544'
    Add-LocalGroupMember -Group $admins -Member $u
    Write-Step 'User' 'OK' "$UserName created, in $($admins.Name)"; Add-Result 'User' 'OK' $u.SID.Value

    # ---- 4. OpenSSH Server
    $svc = Get-Service -Name 'sshd' -ErrorAction SilentlyContinue
    if ($svc) {
        $state.SshdPreexisting = $true; $state.SshdStatus = [string]$svc.Status
        $state.SshdStartType = [string](Get-CimInstance Win32_Service -Filter "Name='sshd'").StartMode; Save-State $state
        Write-Step 'OpenSSH' 'INFO' "already installed ($($state.SshdStatus), $($state.SshdStartType)) - config left as is"
    } else {
        Write-Step 'OpenSSH' 'INFO' 'installing the OpenSSH Server feature (can take a few minutes)'
        $cap = @(Get-WindowsCapability -Online | Where-Object { $_.Name -like 'OpenSSH.Server*' })[0]
        if (-not $cap) { throw 'OpenSSH Server feature not available on this Windows.' }
        $state.SshdInstalled = $true; Save-State $state
        Add-WindowsCapability -Online -Name $cap.Name | Out-Null
        $svc = Get-Service -Name 'sshd'
    }
    Set-Service -Name 'sshd' -StartupType Automatic
    Start-Service -Name 'sshd'
    $cfg = Join-Path $env:ProgramData 'ssh\sshd_config'
    if ($state.SshdInstalled -and (Test-Path $cfg)) {
        $c = Get-Content $cfg
        if ($c -match '^\s*#?\s*PasswordAuthentication\s') { $c = $c -replace '^\s*#?\s*PasswordAuthentication\s.*$', 'PasswordAuthentication no' } else { $c = @('PasswordAuthentication no') + $c }
        Set-Content -Path $cfg -Value $c -Encoding ASCII
        $state.PasswordAuthOff = $true; Save-State $state
        Restart-Service -Name 'sshd'
    }
    Write-Step 'OpenSSH' 'OK' ("sshd {0}" -f (Get-Service sshd).Status); Add-Result 'OpenSSH' 'OK' $(if ($state.SshdInstalled) { 'installed' } else { 'preexisting' })

    # ---- 5. Bench's key (admins use administrators_authorized_keys)
    $akf = Join-Path $env:ProgramData 'ssh\administrators_authorized_keys'
    if (-not (Test-Path $akf)) {
        New-Item -ItemType File -Path $akf -Force | Out-Null
        $state.KeyFileCreated = $true
        & icacls.exe $akf /inheritance:r /grant '*S-1-5-32-544:F' /grant '*S-1-5-18:F' | Out-Null
    }
    Add-Content -Path $akf -Value $PublicKey -Encoding ASCII
    $state.KeyAdded = $true; Save-State $state
    Write-Step 'Key' 'OK' 'Bench public key added (administrators_authorized_keys)'; Add-Result 'Key' 'OK' $akf

    # ---- 6. firewall: SSH from Tailscale addresses only
    New-NetFirewallRule -DisplayName $fwName -Group 'DTS Bench Access' -Direction Inbound -Protocol TCP -LocalPort 22 -RemoteAddress $SshAllowFrom -Action Allow -Profile Any | Out-Null
    $state.FirewallRule = $true; Save-State $state
    if ($state.SshdInstalled) {
        $def = @(Get-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -ErrorAction SilentlyContinue)
        if ($def.Count -and $def[0].Enabled -eq 'True') { Disable-NetFirewallRule -Name 'OpenSSH-Server-In-TCP'; $state.DefaultRuleDisabled = $true; Save-State $state }
    }
    Write-Step 'Firewall' 'OK' "port 22 from $SshAllowFrom only"; Add-Result 'Firewall' 'OK' $SshAllowFrom

    # ---- 7. PowerShell as the SSH shell + transcription for the window
    $osk = 'HKLM:\SOFTWARE\OpenSSH'
    if (-not (Test-Path $osk)) { New-Item -Path $osk -Force | Out-Null }
    $state.DefaultShellOld = (Get-ItemProperty -Path $osk -Name DefaultShell -ErrorAction SilentlyContinue).DefaultShell
    New-ItemProperty -Path $osk -Name DefaultShell -Value "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force | Out-Null
    $state.DefaultShellSet = $true; Save-State $state
    $tk = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription'
    $tExisting = Get-ItemProperty -Path $tk -ErrorAction SilentlyContinue
    if ($tExisting -and $tExisting.EnableTranscripting) { Write-Step 'Record' 'INFO' "machine already has a transcription policy ($($tExisting.OutputDirectory)) - left as is" }
    else {
        if (-not (Test-Path $tk)) { New-Item -Path $tk -Force | Out-Null }
        New-ItemProperty -Path $tk -Name EnableTranscripting -Value 1 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $tk -Name EnableInvocationHeader -Value 1 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $tk -Name OutputDirectory -Value (Join-Path $Root 'Transcripts') -PropertyType String -Force | Out-Null
        $state.TranscriptionSet = $true; Save-State $state
        Write-Step 'Record' 'OK' "PowerShell transcripts -> $(Join-Path $Root 'Transcripts')"
    }
    Add-Result 'Recording' 'OK' $(if ($state.TranscriptionSet) { 'transcription on' } else { 'existing policy' })

    # ---- 8. Tailscale
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $msi = Join-Path $env:TEMP "tailscale-setup-$stamp.msi"
    Write-Step 'Tailscale' 'INFO' "downloading $TailscaleMsiUrl"
    $pp = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $TailscaleMsiUrl -OutFile $msi -UseBasicParsing
    $ProgressPreference = $pp
    $sig = Get-AuthenticodeSignature -FilePath $msi
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Tailscale') { throw "Tailscale installer signature check failed ($($sig.Status); $($sig.SignerCertificate.Subject))" }
    $state.TailscaleInstalled = $true; Save-State $state
    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList "/i `"$msi`" /qn /norestart TS_UNATTENDEDMODE=always TS_NOLAUNCH=1" -Wait -PassThru
    Remove-Item $msi -Force -ErrorAction SilentlyContinue
    if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010) { throw "Tailscale install exit code $($p.ExitCode)" }
    $ts = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    for ($i = 0; $i -lt 30 -and -not (Test-Path $ts); $i++) { Start-Sleep 2 }
    $tsHost = ('dtsf-' + ($env:COMPUTERNAME.ToLower() -replace '[^a-z0-9-]', '-'))
    $out = & $ts up "--authkey=$AuthKey" "--hostname=$tsHost" --unattended --accept-dns=false --accept-routes=false 2>&1
    $AuthKey = $null
    $ip = ''; for ($i = 0; $i -lt 20 -and -not $ip; $i++) { Start-Sleep 2; $ip = (& $ts ip -4 2>$null | Select-Object -First 1) }
    if (-not $ip) { throw "Tailscale did not come up: $(@($out) -join ' ')" }
    $state.TailscaleIp = [string]$ip; Save-State $state
    Write-Step 'Tailscale' 'OK' "joined as $tsHost, $ip"; Add-Result 'Tailscale' 'OK' "$tsHost $ip"

    Write-Evt 100 ("Bench (DTS) temporary SSH access started by {0}. Tailscale {1} ({2}). Ends {3}; cleanup task {4}{5}. Session record: {6}" -f $id.Name, $tsHost, $ip, $expires, $TaskPath, $TaskName, (Join-Path $Root 'Transcripts'))
    Write-Host ''
    Write-Host ("  READY. Tell Bench:  {0}  ({1})  until {2}" -f $ip, $tsHost, $expires.ToString('g')) -ForegroundColor Green
    Write-Host ("  Bench connects with: ssh -i ~/.ssh/dts_field {0}@{1}" -f $UserName, $ip)
    Write-Host '  End early: Stop-BenchAccess.ps1 (or the Go menu).'
}
catch {
    $failed = $true
    Write-Step 'Error' 'Error' $_.Exception.Message
    Add-Result 'Run' 'Error' $_.Exception.Message
    if ($state) {
        Write-Step 'Rollback' 'INFO' 'undoing what this run changed'
        Save-Logs
        $stopScript = Join-Path $Root 'Stop-BenchAccess.ps1'
        if (-not (Test-Path $stopScript)) { $stopScript = Join-Path $scriptDir 'Stop-BenchAccess.ps1' }
        try { & $stopScript -Root $Root -Reason 'StartFailed' } catch { Write-Step 'Rollback' 'Error' $_.Exception.Message }
    }
}
finally {
    $AuthKey = $null
    if (-not ($failed -and $state)) { Save-Logs }
}
